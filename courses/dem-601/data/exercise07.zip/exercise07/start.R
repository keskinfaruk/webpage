# DEM 601, Exercise set 7. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

life_table <- read_pack("life_table.csv")  # Tarvia's life table, for every question. The last three rows are blank: you fill them in question 2.
survival <- read_pack("survival.csv")      # Question 1. 5px, the probability of surviving each five-year age group, in three periods.
givens <- read_pack("givens.csv")          # Questions 3 and 4. The numbers the questions give you.

print(life_table, row.names = FALSE)
print(survival, row.names = FALSE)
print(givens, row.names = FALSE)
