DEM 601, Exercise set 7: data

life_table.csv  Tarvia's life table, for every question. The last three rows are blank: you fill them in question 2.
survival.csv    Question 1. 5px, the probability of surviving each five-year age group, in three periods.
givens.csv      Questions 3 and 4. The numbers the questions give you.

Columns in life_table.csv:
  x  exact age at the start of the row
  n  width of the row in years (empty for the last row)
  m  death rate
  a  years lived by those who die in the row
  q  probability of dying
  l  survivors at exact age x
  d  deaths in the row
  L  person-years lived in the row
  T  person-years lived above age x
  e  life expectancy at exact age x

Columns in survival.csv:
  x          exact age at the start of the age group
  surviving  5px, the probability of surviving to the next age group

The files are plain text (UTF-8). In R, read them as start.R does:
read.csv(file, fileEncoding = "UTF-8-BOM")
