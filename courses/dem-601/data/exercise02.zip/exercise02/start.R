# DEM 601, Exercise set 2. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

tongoland <- read_pack("tongoland.csv")                      # Question 3
tr_age_distribution <- read_pack("tr_age_distribution.csv")  # Question 5. TurkStat, ABPRS, 2025

print(tongoland, row.names = FALSE)
print(tr_age_distribution, row.names = FALSE)
