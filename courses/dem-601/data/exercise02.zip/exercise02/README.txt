DEM 601, Exercise set 2: data

tongoland.csv            Question 3
tr_age_distribution.csv  Question 5. TurkStat, ABPRS, 2025

UTF-8 with BOM. In R: read.csv(file, fileEncoding = "UTF-8-BOM")
