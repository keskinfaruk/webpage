# DEM 601, Exercise set 4. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

atlantis <- read_pack("atlantis.csv")                # Questions 1 and 2. The last row is the unknown-age group.
turkiye_age_sex <- read_pack("turkiye_age_sex.csv")  # Questions 4 and 5. TurkStat, ABPRS, 2010 and 2025, one row per year and age group, males and females in two columns.
births <- read_pack("births.csv")                    # Question 3. Compute both ages at the date the sheet names.

print(atlantis, row.names = FALSE)
print(turkiye_age_sex, row.names = FALSE)
print(births, row.names = FALSE)
