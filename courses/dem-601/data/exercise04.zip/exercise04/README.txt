DEM 601, Exercise set 4: data

atlantis.csv         Questions 1 and 2. The last row is the unknown-age group.
turkiye_age_sex.csv  Questions 4 and 5. TurkStat, ABPRS, 2010 and 2025, one row per year and age group, males and females in two columns.
births.csv           Question 3. Compute both ages at the date the sheet names.

UTF-8 with BOM. In R: read.csv(file, fileEncoding = "UTF-8-BOM")
