# DEM 601, Exercise set 6. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

districts <- read_pack("districts.csv")    # Questions 1 to 3. Kestria and its districts: people counted at mid-year and deaths registered in the year. Corve has no deaths by age, which is the point of question 3.
early_life <- read_pack("early_life.csv")  # Questions 4 and 5. Two years with no threshold, and the later year again counting only births from 28 weeks or 1,000 grams.
givens <- read_pack("givens.csv")          # Question 3. The scalars the question hands you: Corve's total deaths and Dral's two counts.

print(districts, row.names = FALSE)
print(early_life, row.names = FALSE)
print(givens, row.names = FALSE)
