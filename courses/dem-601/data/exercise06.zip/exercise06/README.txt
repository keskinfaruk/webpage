DEM 601, Exercise set 6: data

districts.csv   Questions 1 to 3. Kestria and its districts: people counted at mid-year and deaths registered in the year. Corve has no deaths by age, which is the point of question 3.
early_life.csv  Questions 4 and 5. Two years with no threshold, and the later year again counting only births from 28 weeks or 1,000 grams.
givens.csv      Question 3. The scalars the question hands you: Corve's total deaths and Dral's two counts.

UTF-8 with BOM. In R: read.csv(file, fileEncoding = "UTF-8-BOM")
