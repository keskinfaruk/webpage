# DEM 601, Exercise set 3. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

givens <- read_pack("givens.csv")          # Questions 1 and 3. Rates are per 1,000: divide before use.
turkiye <- read_pack("turkiye.csv")        # Question 2. Census, then ABPRS counts on 31 December.
countries <- read_pack("countries.csv")    # Question 4. UN World Population Prospects 2024, estimates for 2023. Populations in millions.
components <- read_pack("components.csv")  # Question 5. UN World Population Prospects 2024, estimates for 2023. Rates in % a year.

print(givens, row.names = FALSE)
print(turkiye, row.names = FALSE)
print(countries, row.names = FALSE)
print(components, row.names = FALSE)
