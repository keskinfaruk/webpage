DEM 601, Exercise set 3: data

givens.csv      Questions 1 and 3. Rates are per 1,000: divide before use.
turkiye.csv     Question 2. Census, then ABPRS counts on 31 December.
countries.csv   Question 4. UN World Population Prospects 2024, estimates for 2023. Populations in millions.
components.csv  Question 5. UN World Population Prospects 2024, estimates for 2023. Rates in % a year.

UTF-8 with BOM. In R: read.csv(file, fileEncoding = "UTF-8-BOM")
