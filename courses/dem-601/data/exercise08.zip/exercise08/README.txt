DEM 601, Exercise set 8: data

life_table.csv  Türkiye's life table for women, for questions 1 to 4. Cells A to H and the last row's a, L, T and e are yours to compute.

Columns in life_table.csv:
  x  exact age at the start of the row
  n  width of the row in years (empty for the last row)
  m  death rate
  a  years lived by those who die in the row
  q  probability of dying
  p  probability of surviving
  l  survivors at exact age x
  d  deaths in the row
  L  person-years lived in the row
  T  person-years lived above age x
  e  life expectancy at exact age x
A letter in a cell (A to H) is a blank you compute in question 1.

The files are plain text (UTF-8). In R, read them as start.R does:
read.csv(file, fileEncoding = "UTF-8-BOM")
