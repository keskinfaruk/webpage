# DEM 601, Exercise set 8. Run from the folder holding the CSVs.
read_pack <- function(file) read.csv(file, fileEncoding = "UTF-8-BOM")

life_table <- read_pack("life_table.csv")  # Türkiye's life table for women, for questions 1 to 4. Cells A to H and the last row's a, L, T and e are yours to compute.

print(life_table, row.names = FALSE)
