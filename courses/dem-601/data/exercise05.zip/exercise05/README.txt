DEM 601, Exercise set 5: data

toyland.csv         Questions 1 and 2. Rates are per 1,000 a year; the two percentage columns are each sex's own distribution across the age groups.
toyland_givens.csv  Questions 1 and 2. Toyland's three given figures. The sex ratio is stored as males per hundred females.
census_bands.csv    Question 2. TurkStat, 2000 General Population Census, cut into the age groups Toyland's rates were measured on. The last row is the unknown-age group.
deaths_age_sex.csv  Questions 3 and 4. TurkStat, Vital Statistics, 2025. Person-years are the mean of the two year-end register counts.
sentences.csv       Question 4(b). The three sentences to diagnose.
causes.csv          Question 5. Deaths by cause, both sexes: TurkStat, Causes of Death Statistics. All deaths and the mid-year population: TurkStat, Vital Statistics.

UTF-8 with BOM. In R: read.csv(file, fileEncoding = "UTF-8-BOM")
